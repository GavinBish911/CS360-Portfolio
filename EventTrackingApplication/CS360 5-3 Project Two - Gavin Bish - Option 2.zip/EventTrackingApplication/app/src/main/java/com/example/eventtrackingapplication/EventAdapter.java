package com.example.eventtrackingapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private final List<String> events;
    private final OnEventActionListener listener;

    // Constructor
    public EventAdapter(List<String> events, OnEventActionListener listener) {
        this.events = events;
        this.listener = listener;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_item, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        String event = events.get(position);
        holder.eventTitle.setText(event);

        holder.deleteButton.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDeleteEvent(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    // ViewHolder Class
    static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView eventTitle;
        Button deleteButton;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventTitle = itemView.findViewById(R.id.eventTitle);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    // Listener Interface
    public interface OnEventActionListener {
        void onDeleteEvent(int position);
    }
}
