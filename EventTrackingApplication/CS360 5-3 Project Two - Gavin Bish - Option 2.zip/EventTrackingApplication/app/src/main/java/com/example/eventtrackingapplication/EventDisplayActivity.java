package com.example.eventtrackingapplication;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class EventDisplayActivity extends AppCompatActivity implements EventAdapter.OnEventActionListener {

    private RecyclerView eventRecyclerView;
    private EventAdapter eventAdapter;
    private List<String> events;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_display);

        // Reference to RecyclerView and Button
        RecyclerView eventRecyclerView = findViewById(R.id.eventRecyclerView);
        Button addEventButton = findViewById(R.id.addEventButton);

        // Setup RecyclerView
        List<String> events = new ArrayList<>();
        EventAdapter eventAdapter = new EventAdapter(events, this);
        eventRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        eventRecyclerView.setAdapter(eventAdapter);

        // Add mock data (if needed)
        events.add("Meeting at 10 AM");
        events.add("Conference Call at 2 PM");

        // Add button click listener
        addEventButton.setOnClickListener(v -> {
            // Logic to add a new event
            String newEvent = "New Event at " + System.currentTimeMillis(); // Example event
            events.add(newEvent);
            eventAdapter.notifyItemInserted(events.size() - 1);
        });
    }

    @Override
    public void onDeleteEvent(int position) {
        if (position >= 0 && position < events.size()) { // Check if position is valid
            events.remove(position);
            eventAdapter.notifyItemRemoved(position);
        } else {
            Log.e("EventDisplayActivity", "Invalid position: " + position);
        }
    }
}
