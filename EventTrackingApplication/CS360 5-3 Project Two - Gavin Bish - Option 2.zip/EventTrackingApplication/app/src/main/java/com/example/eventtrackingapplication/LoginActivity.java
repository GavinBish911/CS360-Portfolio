package com.example.eventtrackingapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        loginButton.setOnClickListener(view -> {
            // Implement login logic
            startActivity(new Intent(LoginActivity.this, EventDisplayActivity.class));
        });

        createAccountButton.setOnClickListener(view -> {
            // Implement account creation logic
        });
    }
}
